import express from 'express';
import mongoose from 'mongoose';
import roleRouter from './routes/role.js';
import authRouter from './routes/auth.js';
import userRouter from './routes/user.js';
import dotenv from 'dotenv';


dotenv.config();
const app = express();
app.use(express.json())
 


const connectionMongoDB = async ()=>{
    try{
        await mongoose.connect(process.env.MONGO_URI);
        console.log("DB Connection SuccessFul");
    }
    catch (error){
        console.log(error);
    }
} 
app.listen(3000,()=>{
    connectionMongoDB();
    console.log("Connected to Backend");
})

app.use('/api/role', roleRouter);
app.use("/api/auth", authRouter);
app.use('/api/user', userRouter);

//Error Handler MiddleWare 

app.use((obj,req,res,next)=>{
    const statusCode = obj.status || 500;
    const message  = obj.message || "Something went wrong";

    return res.status(statusCode).json({
        success:[200,201,204].some(a => a === obj.status)?true:false,
        status:statusCode,
        message:message,
        data :obj.data,
        
    });
})

app.use('/',(req,res)=>{
    return res.send("<h1>Hello Auth<h1>");
})

