import express from 'express';
import { getAllUsers,getById } from '../contollers/user.controller.js';

const router = express.Router();

router.get('/', getAllUsers);
router.get('/:id', getById);




export default router;